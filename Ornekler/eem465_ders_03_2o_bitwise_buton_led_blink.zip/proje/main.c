#include <stdint.h>
#define RCC_AHB1ENR		*((uint32_t*) 0x40023830)
#define GPIOD_MODER		*((uint32_t*) 0x40020C00)
#define GPIOA_IDR 		*((uint32_t*) 0x40020010)
#define GPIOD_ODR		*((uint32_t*) 0x40020C14)


uint32_t setbit(uint32_t a, int n){
	uint32_t b=0x01;
	a = a | (b<<n);
	return a;
}

uint32_t clearbit(uint32_t a, int n){
	uint32_t b=1;
	a = a & ~(b<<n);
	return a;
}


uint32_t testbit(uint32_t a, int n){
	uint32_t b=0x01;
	a= (a>>n) & b;
	return a;
}
void delay(){
	int i;
	for(i=0;i<1000000;i++);
}

int main(void){
	
	uint32_t a=0; // bu ifade (unsigned int a) ile ayni
	uint32_t b;
	uint32_t c;
	
	a=setbit(a,0);
	a=setbit(a,3);
	RCC_AHB1ENR = RCC_AHB1ENR | a;
	
	a=0;
	a=setbit(a,24);
	a=setbit(a,26);
	a=setbit(a,28);
	a=setbit(a,30);
	GPIOD_MODER = GPIOD_MODER | a; 
	while(1){
		b=GPIOA_IDR;
		if(testbit(b,0)==1){
			a=0;
			a=setbit(a,15);
			a=setbit(a,14);
			a=setbit(a,13);
			a=setbit(a,12);
			GPIOD_ODR = GPIOD_ODR | a;
			delay();
			c=0x0;
			c= ~c;
			
			c=clearbit(c,15);
			c=clearbit(c,14);
			c=clearbit(c,13);
			c=clearbit(c,12);
			GPIOD_ODR = GPIOD_ODR & c;
			
			delay();
		}
	}
	return 1;
}