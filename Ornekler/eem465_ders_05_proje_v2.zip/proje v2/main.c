#include "stm32f407xx.h"                  // Device header

void delay(void);

int main(){
	
	// stm32f407xx.h dosyasinin 613, 1129. satiri
	// RCC->AHB1ENR |=  (1U << 3); 
	// stm32f407xx.h dosyasinda 9894. satirindan baslayan tanimlamalar
	// 9906. satir
	RCC->AHB1ENR |=  RCC_AHB1ENR_GPIODEN;
	
	
	// stm32f407xx.h dosyasinin 543, 1122. satiri
	// GPIOD->MODER |= (1U << 30); 
	// stm32f407xx.h dosyasinda 8048. satirindan baslayan tanimlamalar
	// 8127. satir
	GPIOD->MODER |= GPIO_MODER_MODE15_0;
	
	
	// stm32f407xx.h dosyasinin 543, 1122. satiri
	// GPIOD->ODR |= 1U << 15; // ON icin
	// GPIOD->ODR &= ~(1U << 15); // OFF icin
	
	// stm32f407xx.h dosyasinda 8612. satirindan baslayan tanimlamalar
	// 8660. satir
	// ON yapmak icin
	// GPIOD->ODR |= GPIO_ODR_OD15;
	// OFF yapmak icin
	// GPIOD->ODR &= ~GPIO_ODR_OD15;
	
	while(1){
		
		GPIOD->ODR |= GPIO_ODR_OD15;
		
		delay();
		
		GPIOD->ODR &= ~GPIO_ODR_OD15;
		
		delay();
	}
	
	return 1;
}

void delay(void){
	int i;
	for(i=0;i<1000000;i++);
}
	