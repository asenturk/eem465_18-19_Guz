#include "Board_LED.h"                  // ::Board Support:LED


void delay(void){
int i;
	for(i=0;i<1000000;i++);
}

int main(void){
int i;

LED_Initialize();

for(;;){
	
	for(i=0;i<4;i++)
		LED_On(i);	
	delay();
	for(i=0;i<4;i++)
		LED_Off(i);
	delay();
}

	return 1;
}
