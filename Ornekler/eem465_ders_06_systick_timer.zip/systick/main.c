#include "stm32f4xx.h"                  // Device header
#include <stdint.h>


//ststick tanimlamalari core_cm4.h 757. satirdan itibaren
void systick_init(uint32_t ticks){ // 1s:16000000UL if CLKSOURCE==0
	//SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk; // CLKSOURCE (2. bit) 1 yapar //system_clock_freq
	SysTick->CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk; // CLKSOURCE (2. bit) 0 yapar // system_clock_freq/8
	
	//SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk; // CLKSOURCE (1. bit) 1 yapar // interrupt enable
	SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk; // CLKSOURCE (1. bit) 1 yapar // interrupt disable
	
	SysTick->VAL = 0UL; // Current Value Register
	SysTick->LOAD = SysTick_LOAD_RELOAD_Msk & ticks; // Reload Value Register
	
	
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; // CLKSOURCE (0. bit) 1 yapar // timer start
	//SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk; // CLKSOURCE (0. bit) 0 yapar // timer disable
}

void wait1systick(void){
	while(!(SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk));
}

int main(void){
	
	// GPIOD init
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
	GPIOD->MODER |= GPIO_MODER_MODE15_0;
	
	
	systick_init(16000000UL);
	
	
	while(1){
		GPIOD->ODR |= GPIO_ODR_OD15;
		wait1systick();
		GPIOD->ODR &= ~GPIO_ODR_OD15;
		wait1systick();
	}
	
	return 1;
}
