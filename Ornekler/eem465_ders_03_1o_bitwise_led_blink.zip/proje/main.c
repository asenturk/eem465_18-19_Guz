#include <stdint.h>
#define RCC_AHB1_ENR 	*(( uint32_t *) 0x40023830)
#define GPIOD_MODER 	*(( uint32_t *) 0x40020C00)
#define GPIOD_ODR 		*(( uint32_t *) 0x40020C14)


uint32_t setbit(uint32_t a, int n){
	uint32_t b=0x01;
	b = b << n;
	a = a | b;
	return a;
}

uint32_t clearbit(uint32_t a, int n){
	uint32_t b=0x01;
	b = b << n;
	b = ~b;
	a = a & b;
	return a;
}

void delay(void){
	int i;
	for(i=0;i<1000000;i++);
}

int main(void){
	
	uint32_t a=0;
	uint32_t b=0x0;
	a=setbit(a, 3);
	
	RCC_AHB1_ENR = RCC_AHB1_ENR | a;
	
	a=0;
	a=setbit(a,30);
	GPIOD_MODER = GPIOD_MODER | a;
	
	while(1){
		a=0;
		a=setbit(a,15);
		GPIOD_ODR = GPIOD_ODR | a;
		delay();
		a=~b;
		a=clearbit(a,15);
		GPIOD_ODR = GPIOD_ODR & a;
		delay();
	}	
	return 1;
}
