#include "stm32f4xx.h"                  // Device header

unsigned long int H,L, arttir=1;


void systick_init(){ 
	
	SysTick->CTRL &= ~SysTick_CTRL_ENABLE_Msk; // ENABLE (0. bit) 0 yapar // timer disable
	SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk; // CLKSOURCE (2. bit) 1 yapar //system_clock_freq
	//SysTick->CTRL &= ~SysTick_CTRL_CLKSOURCE_Msk; // CLKSOURCE (2. bit) 0 yapar // system_clock_freq/8
	SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk; // TICKINT (1. bit) 1 yapar // interrupt enable
	//SysTick->CTRL &= ~SysTick_CTRL_TICKINT_Msk; // TICKINT (1. bit) 0 yapar // interrupt disable
	
	SysTick->VAL = 0UL; // Current Value Register
	
	SysTick->LOAD = SysTick_LOAD_RELOAD_Msk & L; // Reload Value Register // Yuklenecek Deger
	
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk; // ENABLE (0. bit) 1 yapar // timer start
}

void SysTick_Handler(void){
	
	if(H>(80000-150)){
		arttir=0;
	}
	if(H<(150)){
		arttir=1;
	}
	
	if(arttir==1){
		//H'yi %.1 oraninda arttir
		H=H+80;
		L=80000-H;
	}else{
		//H'yi %.1 oraninda azalt
		H=H-80;
		L=80000-H;
	}
	
	if(GPIOD->ODR & GPIO_ODR_OD15){ // led yaniyor ise
		//make pin 0
		GPIOD->ODR &= ~GPIO_ODR_OD15;
		//systicke L'yi yukle
		SysTick->LOAD = SysTick_LOAD_RELOAD_Msk & L;
		
	}else{//led sonuk ise
		//make pin 1
		GPIOD->ODR |= GPIO_ODR_OD15;
		//systicke H'yi yukle
		SysTick->LOAD = SysTick_LOAD_RELOAD_Msk & H;
	}
	
	
}

int main(){

	H=40000UL;
	L=40000UL;
	
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
	GPIOD->MODER |=  GPIO_MODER_MODE15_0;
	GPIOD->ODR |= GPIO_ODR_OD15;

	systick_init();
	//NIVIC systick interrup etkinlestirildi.
	NVIC_EnableIRQ(SysTick_IRQn);
	
	
	while(1);
	
	return 1;
}
