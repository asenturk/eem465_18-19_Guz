#include "stm32f4xx.h"                  // Device header

unsigned long int LED_i=0;

void EXTI0_IRQHandler(void){
	
	//pending register control
	if(EXTI->PR & EXTI_PR_PR0)
		EXTI->PR |= EXTI_PR_PR0;
	
	LED_i++;
}

int main(){
	
	//A ve D portlari etkinlestirildi
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
	
	//D portunun 12,13,14,15. pinleri output olarak ayarlandi.
	GPIOD->MODER |= (GPIO_MODER_MODE12_0 | GPIO_MODER_MODE13_0 | GPIO_MODER_MODE14_0 | GPIO_MODER_MODE15_0);

	//NIVIC te 6 nolu interrupt etkinlesitirildi.
	//NVIC_EnableIRQ(6);
	NVIC_EnableIRQ(EXTI0_IRQn);
	
	// A portunun 0. pinine bagli bton icin interrupt maski etkinlestirildi.
	EXTI->IMR |= EXTI_IMR_IM0; 
	
	//A portunun 0. pinine bagli butona basildiginda 0'dan 1'e gecme durumunda interrup olacak.
	EXTI->RTSR |= EXTI_RTSR_TR0;
	
	while(1){
		//All LEDs are OFF
		GPIOD->ODR &= ~(GPIO_ODR_OD12 | GPIO_ODR_OD13 | GPIO_ODR_OD14 | GPIO_ODR_OD15);	
		// LED i ON		
		GPIOD->ODR |= 1U << 12+(LED_i%4);
	}
	
	return 1;
}
