#include "stm32f4xx.h"                  // Device header

void delay();

int main(){
	
	RCC->AHB1ENR |=  (1U << 3); //stm32f407xx.h dosyasinin 613, 1129. satiri
	
	GPIOD->MODER |= (1U << 30); //stm32f407xx.h dosyasinin 543, 1122. satiri
	
	GPIOD->ODR |= 1U << 15; //stm32f407xx.h dosyasinin 543, 1122. satiri
	
	while(1){
		GPIOD->ODR |= 1U << 15;
		delay();
		
		GPIOD->ODR &= ~(1U << 15);
		
		delay();
	}
	
	return 1;
}

void delay(){
	int i;
	for(i=0;i<1000000;i++);
}
	