#include "stm32f4xx.h"                  // Device header
#include <stdint.h>


void delay(void);

int main(void){
	
	
	RCC->CR |= RCC_CR_HSEON;
	while( !(RCC->CR & RCC_CR_HSERDY));
	
	RCC->CFGR |= RCC_CFGR_SW_HSE;
	
	
	
	
	
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
	GPIOD->MODER |= GPIO_MODER_MODE15_0;
	
	
	while(1){
		GPIOD->ODR |= GPIO_ODR_OD15;
		delay();
		GPIOD->ODR &= ~GPIO_ODR_OD15;
		delay();
	}
	
	
	
	return 1;
}

void delay(void){
	int i;
	for(i=0;i<9000000;i++); // internal clock appr 3 sec
}

