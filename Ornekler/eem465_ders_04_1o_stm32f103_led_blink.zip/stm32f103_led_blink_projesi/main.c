#include <stdint.h>

#define RCC_APB2ENR			*((volatile uint32_t *) 0x40021018)
#define GPIOC_CRH				*((volatile uint32_t *) 0x40011004)
#define GPIOC_ODR				*((volatile uint32_t *) 0x4001100C)

void delay(){
	int i;
	for(i=0;i<1000000;i++);
}

int main(void){
	
	RCC_APB2ENR |= 0x01U << 4;
	GPIOC_CRH |= 0x01U << 21;
	
	while(1){
		GPIOC_ODR |= 0x01U << 13;
		delay();
		GPIOC_ODR &= ~((uint32_t) 0x01U << 13);
		delay();
	}
	
	return 1;
}


______________



#include <stdio.h>

int main(int argc, char *argv[]) {

	int a=0xabcd;
	
	printf("%d\n",(unsigned char) a);
	
	printf("%d\n",sizeof(unsigned short));
	printf("%x\n",(unsigned short) 0xabcdef7);

	return 0;
}


______________


______________
#include <stdio.h>

int main(int argc, char *argv[]) {

	int i=10, *p1, *p2;
	
	p1=&i;
	
	printf("i degiskeninin adresi: %d\n",&i);
	printf("p isaretcisinin adresi: %d\n",&p1);
	printf("p isaretcisinde saklanan deger: %d\n",p1);
	printf("p isaretcisinin isaret ettigi yerdeki deger: %d\n",*p1);
	

	return 0;
}



______________
#include <stdio.h>

int main(int argc, char *argv[]) {

	int i=10, *p1, *p2;
	
	p1=&i;
	p2=p1;
	
	printf("i degiskeninin adresi: %d\n",&i);
	printf("i degiskeninde saklanan deger: %d\n",i);
	
	
	printf("p1 isaretcisinin adresi: %d\n",&p1);
	printf("p1 isaretcisinde saklanan deger: %d\n",p1);
	printf("p1 isaretcisinin isaret ettigi yerdeki deger: %d\n",*p1);
	
	printf("p2 isaretcisinin adresi: %d\n",&p2);
	printf("p2 isaretcisinde saklanan deger: %d\n",p2);
	printf("p2 isaretcisinin isaret ettigi yerdeki deger: %d\n",*p2);
	

	return 0;
}



______________
#include <stdio.h>
void f1(int a){
	a=10;
}

int main(int argc, char *argv[]) {

	int a=5;
	f1(a);
	printf("a: %d",a);


	return 0;
}


