#include "stm32f4xx.h" 

int main ()  { 
	int i;
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	GPIOA->MODER |= GPIO_MODER_MODE1; //1 portunun 1. pininin modu analog olarak ayarlandi.
	//default mode no pull up pull down
	GPIOA->PUPDR &= ~GPIO_PUPDR_PUPD1;
	
	//ADC APB2'ye bagli oldugu icin APB2'nin clocku etkinlestirildi.
	RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;

	//25:24 bitlerine 00 yazilarak ��z�n�rl�k 12 bit yapildi. Ayni zamanda 15 ADCCLK cycles
	ADC1->CR1 &= ~ADC_CR1_RES; 
	
	
	

	//8. bit 1 yapilarak SCAN modu etkinlestiriliyor.
	// SCAN modunda input ADC_SQRx yazmaciyla seciliyor.
	ADC1->CR1 |= ADC_CR1_SCAN;

	
	// 1. siradaki �evirme isleminde ADC 1. kanal se�iliyor. (AP1)
	ADC1->SQR3 |= ADC_SQR3_SQ1_0;
	
	//Saga yasli
	ADC1->CR2 &= ~ADC_CR2_ALIGN;
	
	//ADC'ye enerji veriliyor. Power ONN
	ADC1->CR2 |= ADC_CR2_ADON;
	
	while(1){
	ADC1->CR2 |= ADC_CR2_SWSTART;
	for(i=0;i<10000;i++);
	ADC1->SR &= ~ADC_SR_EOC;
	}
	return 1;
}
