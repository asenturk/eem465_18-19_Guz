#include "stm32f4xx.h"                  // Device header


void PLL_init(void){
	
	//harici cevrim kaynagi aktif hale getiriliyor.
	RCC->CR |= RCC_CR_HSEON;
	while( !(RCC->CR & RCC_CR_HSERDY));
	
	RCC->CR &= ~RCC_CR_PLLON;//PLL ayarlamalari yapilabilmesi icin PLL OFF durumna getiriliyor.
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLSRC_HSE; //harici kaynak PLL'i besleyecek sekilde 22. bit ayarlaniyor. 
	//RCC->PLLCFGR &= ~(0x01UL << 22);
	
	RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLM_Msk; //M b�lgesi 0 yapiliyor.
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLM_3; //M degeri 8 olarak ayarlaniyor.
	
	RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLN_Msk; //N b�lgesi 0 yapiliyor.
	RCC->PLLCFGR |= (336UL << RCC_PLLCFGR_PLLN_Pos); //VCO cikisi 336 MHz olarak ayarlandi.
	
	
	//burasi 8'e bolecek sekilde olursa problem yok...
	RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLP;
	RCC->PLLCFGR |= RCC_PLLCFGR_PLLP; //P bolgesi 11 yapilarak VCO'nun 8'e bolunmesi saglaniyor.
	//RCC->PLLCFGR &= ~RCC_PLLCFGR_PLLP;//P bolgesi 00 yapilarak VCO'nun 2'ye bolunmesi saglaniyor.

	
	
	RCC->CR |= RCC_CR_PLLON; //PLL ON duruma getiriliyor.
	while( !(RCC->CR & RCC_CR_PLLRDY)); //PLL stabil hale gelene kadar bekle.
	
	
	RCC->CFGR |= RCC_CFGR_SW_PLL;//PLL sistem cevrim kaynagi olarak devreye aliniyor.


	//set bus freq
	
	RCC->CFGR &= ~RCC_CFGR_HPRE; // belirtilen bolge 0 yapiliyor.
	RCC->CFGR |= RCC_CFGR_HPRE_DIV1; //0 yazilarak system clock bolunmuyor. AHB clock = system bus
	
	
	
	RCC->CFGR  &= ~RCC_CFGR_PPRE1; //apb1 bolgesi prescaler degeri 0 yapiliyor.
	RCC->CFGR  |= RCC_CFGR_PPRE1_DIV16; // AHB cevrimi 16 ile bolunuyor.
	
	RCC->CFGR  &= ~RCC_CFGR_PPRE2; //apb2 bolgesi prescaler degeri 0 yapiliyor.
	RCC->CFGR  |= RCC_CFGR_PPRE2_DIV16; // AHB cevrimi 16 ile bolunuyor.
	
	
}

void delay(void){
	int i;
	for(i=0;i<3000000;i++); 
}


int main(void){
	
	
	
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
	GPIOD->MODER |= GPIO_MODER_MODE15_0;
	
	
	//PLL_init();
	
	SystemCoreClockUpdate();

	
	while(1){
		GPIOD->ODR |= GPIO_ODR_OD15;
		delay();
		GPIOD->ODR &= ~GPIO_ODR_OD15;
		delay();
	}

	
	return 1;
}
